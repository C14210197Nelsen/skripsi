<?php

namespace App\Http\Controllers;

use Carbon\Carbon;
use App\Models\Product;
use App\Models\Customer;
use App\Models\Salesorder;
use App\Models\Returnorder;
use App\Models\Salesdetail;
use App\Models\StockLedger;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;


class ControllerSales extends Controller
{
    public function index(Request $request)
    {
        // Cek Filter Valid
        if ($request->filled('from') && $request->filled('to')) {
            $from = Carbon::createFromFormat('Y-m', $request->from)->startOfMonth();
            $to = Carbon::createFromFormat('Y-m', $request->to)->endOfMonth();

            if ($from > $to) {
                return back()->withErrors(['from' => 'Bulan 1 tidak boleh setelah bulan 2.'])->withInput();
            }
        }

        // Query Database
        $query = Salesorder::with('customer')
            ->where('status', 1)
            ->orderBy('salesDate', 'desc')
            ->orderBy('salesID', 'desc');

        if ($request->filled('customer_id')) {
            $query->where('Customer_customerID', $request->customer_id);
        }

        if ($request->filled('from')) {
            $from = Carbon::createFromFormat('Y-m', $request->from)->startOfMonth();
            $query->whereDate('salesDate', '>=', $from);
        }

        if ($request->filled('to')) {
            $to = Carbon::createFromFormat('Y-m', $request->to)->endOfMonth();
            $query->whereDate('salesDate', '<=', $to);
        }

        // Pagination
        $salesorders = $query->paginate(10)->withQueryString();
        $customers = Customer::where('status', 1)->get();

        return view('sales.index', [
            'title' => 'Sales',
            'user' => 'Nama',
            'salesorders' => $salesorders,
            'customers' => $customers,
        ]);
    }

    public function create()
    {
        // Get Data
        $customers = Customer::where('status', 1)->get();
        $products = Product::where('status', 1)->with('latestStockLedger')->get();

        return view('sales.create', [
            'title' => 'Create Sales',
            'user' => 'Nama',
            'customers' => $customers,
            'products' => $products,
        ]);
    }

    public function store(Request $request)
    {
        // Validasi Data
        $request->validate([
            'customer_id' => 'required|exists:customer,customerID',
            'salesDate' => 'required|date',
            'products' => 'required|array',
            'products.*.productCode' => 'required|exists:product,productCode',
            'products.*.quantity' => 'required|integer|min:1',
            'products.*.price' => 'required|numeric|min:0',
        ]);

        // Cek Data Produk
        foreach ($request->products as $item) {
            $product = Product::where('productCode', $item['productCode'])->firstOrFail();

            if (!$product->status) {
                return back()->withErrors([
                    'stok' => "Produk {$product->productCode} tidak aktif dan tidak dapat dijual."
                ])->withInput();
            }
            
            $latest = StockLedger::where('productID', $product->productID)->latest('created_at')->first();
            $saldo = $latest->saldo_qty ?? 0;

            if ($saldo < $item['quantity']) {
                return back()->withErrors([
                    'stok' => "Stok produk {$product->productCode} tidak mencukupi. Tersisa $saldo."
                ])->withInput();
            }
        }

        // Create SO Header
        $salesOrder = Salesorder::create([
            'salesDate' => $request->salesDate,
            'Customer_customerID' => $request->customer_id,
            'status' => 1,
            'totalPrice' => 0,
            'totalHPP' => 0,
            'totalProfit' => 0,
        ]);

        $totalPrice = 0;
        $totalHPP = 0;

        // Create SO Detail & Stock Ledger
        foreach ($request->products as $item) {
            $product = Product::where('productCode', $item['productCode'])->firstOrFail();
            $qty = $item['quantity'];
            $price = $item['price'];

            $last = StockLedger::where('productID', $product->productID)->latest('created_at')->first();
            $hpp = ($last && $last->saldo_qty > 0) ? $last->saldo_harga / $last->saldo_qty : 0;

            $subtotal = $price * $qty;
            $total_cost = $hpp * $qty;

            Salesdetail::create([
                'SalesOrder_salesID' => $salesOrder->salesID,
                'Product_productID' => $product->productID,
                'quantity' => $qty,
                'price' => $price,
                'subtotal' => $subtotal,
                'cost' => $total_cost,
            ]);

            $saldo_qty = $last->saldo_qty - $qty;
            $saldo_harga = $last->saldo_harga - $total_cost;

            StockLedger::create([
                'productID' => $product->productID,
                'qty' => -$qty,
                'saldo_qty' => $saldo_qty,
                'saldo_harga' => $saldo_harga,
                'price' => null,
                'total_price' => null,
                'hpp' => $hpp,
                'type' => 'Sales-Out',
                'source_type' => 'SO',
                'source_id' => $salesOrder->salesID,
            ]);

            $totalPrice += $subtotal;
            $totalHPP += $total_cost;
        }

        $salesOrder->update([
            'totalPrice' => $totalPrice,
            'totalHPP' => $totalHPP,
            'totalProfit' => $totalPrice - $totalHPP,
        ]);

        return redirect()->route('sales.create')->with('success', 'Transaksi berhasil disimpan.');
    }

    public function show($id)
    {
        $salesorder = Salesorder::with(['customer', 'details.product'])->findOrFail($id);

        return view('sales.show', [
            'title' => 'Sales Order Detail',
            'user' => 'Nama',
            'salesorder' => $salesorder
        ]);
    }

    public function edit($id)
    {
        $salesorder = Salesorder::with(['customer', 'details.product'])->findOrFail($id);

        $customers = Customer::where('status', 1)
            ->orWhere('customerID', $salesorder->Customer_customerID)
            ->get();

        $products = Product::where('status', 1)->with('latestStockLedger')->get();

        return view('sales.edit', [
            'title' => 'Sales Order Edit',
            'user' => 'Nama',
            'salesorder' => $salesorder,
            'customers' => $customers,
            'products' => $products,
        ]);
    }

    public function update(Request $request, $id)
    {

        // Validasi Data
        $request->validate([
            'customer_id' => 'required|exists:customer,customerID',
            'salesDate' => 'required|date',
            'products' => 'required|array',
            'products.*.productCode' => 'required|exists:product,productCode',
            'products.*.quantity' => 'required|integer|min:0',
            'products.*.price' => 'required|numeric|min:0',
        ]);

        // Cek stok
        foreach ($request->products as $item) {
            $product = Product::where('productCode', $item['productCode'])->firstOrFail();
            $qty = $item['quantity'];
            $productID = $product->productID;

            $salesorder = Salesorder::with('details')->findOrFail($id);
            $oldDetails = $salesorder->details->keyBy('Product_productID');
            $oldQty = $oldDetails[$productID]->quantity ?? 0;
            $needed = $qty - $oldQty;

            if ($needed > 0) {
                $last = StockLedger::where('productID', $productID)->latest('created_at')->first();
                $saldo_qty = $last->saldo_qty ?? 0;

                if ($saldo_qty < $needed) {
                    return back()->withErrors([
                        'stok' => "Stok produk {$product->productCode} tidak mencukupi. Tersisa $saldo_qty."
                    ])->withInput();
                }
            }
        }

        DB::transaction(function () use ($request, $id) {
            $salesorder = Salesorder::with('details')->findOrFail($id);
            $oldDetails = $salesorder->details->keyBy('Product_productID');
            $salesorder->details()->delete();

            $totalPrice = 0;
            $totalHPP = 0;

            $updatedProductIDs = [];

            // Membuat SO Detail dan Stock Ledger Baru
            foreach ($request->products as $item) {
                $product = Product::where('productCode', $item['productCode'])->firstOrFail();
                $qty = $item['quantity'];
                $price = $item['price'];
                $productID = $product->productID;
                $updatedProductIDs[] = $productID;

                $last = StockLedger::where('productID', $productID)->latest('created_at')->first();
                $saldo_qty = $last->saldo_qty ?? 0;
                $saldo_harga = $last->saldo_harga ?? 0;

 
                $oldQty = $oldDetails[$productID]->quantity ?? 0;
                $returnedQty = $oldDetails[$productID]->returned ?? 0;
                $oldQty -= $returnedQty;

                $hpp = ($saldo_qty > 0) ? $saldo_harga / $saldo_qty : 0;
                $subtotal = $price * $qty;
                $cost_total = $hpp * $qty;

                Salesdetail::create([
                    'SalesOrder_salesID' => $salesorder->salesID,
                    'Product_productID' => $productID,
                    'quantity' => $qty + $returnedQty,
                    'returned' => $returnedQty,
                    'price' => $price,
                    'subtotal' => $subtotal,
                    'cost' => $cost_total,
                    'status' => 1,
                ]);

                if ($qty > $oldQty) {
                    // Out selisihnya
                    $diff = $qty - $oldQty;
                    $saldo_qty -= $diff;
                    $saldo_harga -= $hpp * $diff;

                    StockLedger::create([
                        'productID' => $productID,
                        'qty' => -$diff,
                        'saldo_qty' => $saldo_qty,
                        'saldo_harga' => $saldo_harga,
                        'price' => null,
                        'total_price' => null,
                        'hpp' => $hpp,
                        'type' => 'Sales-Out',
                        'source_type' => 'SO',
                        'source_id' => $salesorder->salesID,
                    ]);
                } elseif ($qty < $oldQty) {
                    // Return selisihnya
                    $diff = $oldQty - $qty;
                    $saldo_qty += $diff;
                    $saldo_harga += $hpp * $diff;

                    StockLedger::create([
                        'productID' => $productID,
                        'qty' => $diff,
                        'saldo_qty' => $saldo_qty,
                        'saldo_harga' => $saldo_harga,
                        'price' => $hpp,
                        'total_price' => $hpp * $diff,
                        'hpp' => $hpp,
                        'type' => 'Sales-Cancel',
                        'source_type' => 'SO',
                        'source_id' => $salesorder->salesID,
                    ]);
                } elseif ($oldQty == 0) {
                    // New item (belum pernah ada di SO ini)
                    $saldo_qty -= $qty;
                    $saldo_harga -= $hpp * $qty;

                    StockLedger::create([
                        'productID' => $productID,
                        'qty' => -$qty,
                        'saldo_qty' => $saldo_qty,
                        'saldo_harga' => $saldo_harga,
                        'price' => null,
                        'total_price' => null,
                        'hpp' => $hpp,
                        'type' => 'Sales-Out',
                        'source_type' => 'SO',
                        'source_id' => $salesorder->salesID,
                    ]);
                }

                $totalPrice += $subtotal;
                $totalHPP += $cost_total;
            }

            // Jika ada item lama yang dihapus
            foreach ($oldDetails as $productID => $oldDetail) {
                if (!in_array($productID, $updatedProductIDs)) {
                    $qty = $oldDetail->quantity;
                    $cost = $oldDetail->cost / $qty;

                    $last = StockLedger::where('productID', $productID)->latest('created_at')->first();
                    $saldo_qty = ($last->saldo_qty ?? 0) + $qty;
                    $saldo_harga = ($last->saldo_harga ?? 0) + ($cost * $qty);

                    StockLedger::create([
                        'productID' => $productID,
                        'qty' => $qty,
                        'saldo_qty' => $saldo_qty,
                        'saldo_harga' => $saldo_harga,
                        'price' => $cost,
                        'total_price' => $cost * $qty,
                        'hpp' => $cost,
                        'type' => 'Sales-Cancel',
                        'source_type' => 'SO',
                        'source_id' => $salesorder->salesID,
                    ]);
                }
            }

            $salesorder->update([
                'salesDate' => $request->salesDate,
                'Customer_customerID' => $request->customer_id,
                'totalPrice' => $totalPrice,
                'totalHPP' => $totalHPP,
                'totalProfit' => $totalPrice - $totalHPP,
            ]);
        });

        return redirect()->route('sales.index')->with('success', 'Sales order berhasil diperbarui.');
    }



    public function destroy($id)
    {
        DB::transaction(function () use ($id) {
            $salesorder = Salesorder::with('details')->findOrFail($id);

            // Detail dan salesorder tidak aktif
            $salesorder->details()->update(['status' => 0]);
            $salesorder->update(['status' => 0]);

            // Ambil semua detail untuk dibuat ledger return
            foreach ($salesorder->details as $detail) {
                $productID = $detail->Product_productID;
                $qty = $detail->quantity;
                $returned = $detail->returned;
                $cost = ($qty - $returned) != 0 ? $detail->cost / ($qty - $returned) : 0;

                // dd($productID, $qty, $returned, $detail->cost,  $qty - $returned);
  

                // $last = StockLedger::where('productID', $productID)->latest('created_at')->first(); // ini sudah benar, namun saat bikin1 SO dengan 2 item yang sama, lalu delete. stockledgernya salah ambil latest 2 karena created atnya sama
                $last = StockLedger::where('productID', $productID)->latest('stockledgerID')->first();

                $newSaldoQty = ($last->saldo_qty ?? 0) + ($qty - $returned);
                $newSaldoHarga = ($last->saldo_harga ?? 0) + ($cost * ($qty - $returned));
                // dd ($last->saldo_qty, $qty, $returned, $newSaldoQty);
                // Masukkan ledger return
                StockLedger::create([
                    'productID'     => $productID,
                    'qty'           => $qty - $returned,
                    'saldo_qty'     => $newSaldoQty,
                    'saldo_harga'   => $newSaldoHarga,
                    'price'         => $cost,
                    'total_price'   => $cost * ($qty - $returned),
                    'hpp'           => $cost,
                    'type'          => 'Sales-Cancel',
                    'source_type'   => 'SO',
                    'source_id'     => $salesorder->salesID,
                ]);
            }

            Returnorder::where('type', 'sales')
                ->where('sourceID', $salesorder->salesID)
                ->update(['status' => 0]);

        });

        return redirect()->route('sales.index')->with('success', 'Sales order berhasil dibatalkan.');
    }

}
