<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;

class ControllerAjax extends Controller
{
    public function getProductPrice($productCode)
    {
        $product = Product::where('productCode', $productCode)->first();
        if (!$product) return response()->json(['error' => 'Not found'], 404);
        return response()->json(['price' => $product->productPrice]);
    }

    public function getProductCost($productCode)
    {
        $product = Product::where('productCode', $productCode)->first();
        if (!$product) return response()->json(['error' => 'Not found'], 404);
        return response()->json(['cost' => $product->productCost]);
    }
}
