<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Auth;

use Illuminate\Http\Request;

class ControllerHome extends Controller
{
    public function index()
    {
        $user = Auth::user();

        return match ($user->role) {
            'Owner' => view('home.owner', ['title' => 'Home', 'user' => $user->fullName]),
            'Purchase' => view('home.purchase', ['title' => 'Home', 'user' => $user->fullName]),
            'Sales' => view('home.sales', ['title' => 'Home', 'user' => $user->fullName]),
            default => abort(403, 'Role tidak dikenali'),
        };
    }
}
