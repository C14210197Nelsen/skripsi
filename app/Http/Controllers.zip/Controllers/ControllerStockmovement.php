<?php

namespace App\Http\Controllers;

use App\Models\Stockmovement;
use Illuminate\Http\Request;

class ControllerStockmovement extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(Stockmovement $stockmovement)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Stockmovement $stockmovement)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Stockmovement $stockmovement)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Stockmovement $stockmovement)
    {
        //
    }
}
