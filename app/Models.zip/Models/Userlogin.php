<?php

namespace App\Models;

use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Support\Facades\Hash;

class Userlogin extends Authenticatable
{
    protected $table = 'userlogin';
    protected $primaryKey = 'userID'; 
    public $timestamps = false;

    protected $fillable = [
        'username',
        'password',
        'fullName',
        'role',
    ];

    protected $hidden = [
        'password',
    ];

    public static function roleOptions()
    {
        return ['Owner', 'Purchase', 'Sales'];
    }

    public function setPasswordAttribute($value)
    {
        $this->attributes['password'] = strlen($value) < 60
            ? Hash::make($value) : $value;
    }

    public function getAuthIdentifierName()
    {
        return 'userID';
    }

    public function getAuthIdentifier()
    {
        return $this->userID;
    }
}
