<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Returndetail extends Model
{

    protected $table = 'returndetail'; // sesuaikan jika nama tabel bukan plural

    protected $primaryKey = 'returndetailID'; // ganti jika kamu pakai nama lain

    public $timestamps = true; // sesuaikan jika tidak pakai created_at / updated_at

    protected $fillable = [
        'returnID',  // FK ke returnorder
        'productID',     // FK ke product
        'quantity', 
        'price',
        'subtotal'
    ];

    // Relasi ke returnorder
    public function returnorder()
    {
        return $this->belongsTo(Returnorder::class, 'returnID', 'returnID');
    }

    // Relasi ke product
    public function product()
    {
        return $this->belongsTo(Product::class, 'productID', 'productID');
    }
}
