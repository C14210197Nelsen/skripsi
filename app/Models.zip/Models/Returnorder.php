<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Returnorder extends Model
{

    protected $table = 'returnorder'; // jika nama tabel tidak plural

    protected $primaryKey = 'returnID'; // sesuaikan jika bukan 'id'

    public $timestamps = true; // atur false jika tidak pakai created_at / updated_at

    protected $fillable = [
        'type',            // 'sales' atau 'purchase'
        'partnerID',       // FK ke customer / supplier
        'sourceID',        // ID dari salesID atau purchaseID
        'returnDate',      // tanggal return
        'status',          // aktif = 1, nonaktif = 0
    ];

    // Optional: Relasi
    public function returndetail()
    {
        return $this->hasMany(Returndetail::class, 'returnID', 'returnID');
    }
}
